package Modele;

public interface IA {
    int choisirMouvement(GrilleSimple grille);
}
